fx_version 'cerulean'
game 'gta5'
author 'Mr.kujo934'
description 'https://discord.gg/g5gGg8kRHk'

client_scripts {
    'config.lua',
    'pt_timer.lua'
}