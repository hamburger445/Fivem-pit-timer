Config = {}

-- Timer duration in seconds
Config.TimerDuration = 300

-- Screen position for the timer text
Config.TextPosition = {
    x = 0.88,
    y = 0.05
}

-- Customizable command names
Config.Commands = {
    Start = "pt",
    Stop = "endpt"
}
