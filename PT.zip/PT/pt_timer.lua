local isTimerRunning = false
local timer = 0
local showClearMessage = false
local clearMessageTime = 0

RegisterCommand(Config.Commands.Start, function()
    if not isTimerRunning then
        isTimerRunning = true
        timer = Config.TimerDuration
        Citizen.CreateThread(function()
            while timer > 0 and isTimerRunning do
                Citizen.Wait(1000)
                timer = timer - 1
            end
            if isTimerRunning then
                isTimerRunning = false
                showClearMessage = true
                clearMessageTime = GetGameTimer() + 10000
            end
        end)
    else
        TriggerEvent('chat:addMessage', {
            args = {"^1[PIT Timer]", "Timer is already running!"}
        })
    end
end, false)

RegisterCommand(Config.Commands.Stop, function()
    if isTimerRunning then
        isTimerRunning = false
        timer = 0
        showClearMessage = false
        TriggerEvent('chat:addMessage', {
            args = {"^2[PIT Timer]", "Timer stopped."}
        })
    else
        TriggerEvent('chat:addMessage', {
            args = {"^1[PIT Timer]", "No timer is currently running."}
        })
    end
end, false)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if isTimerRunning then
            local minutes = math.floor(timer / 60)
            local seconds = timer % 60
            local timeText = string.format("%02d:%02d", minutes, seconds)

            SetTextFont(4)
            SetTextProportional(1)
            SetTextScale(0.7, 0.7)
            SetTextColour(255, 255, 255, 255)
            SetTextOutline()
            SetTextEntry("STRING")
            AddTextComponentString("PT Timer: " .. timeText)
            DrawText(Config.TextPosition.x, Config.TextPosition.y)
        elseif showClearMessage and GetGameTimer() < clearMessageTime then
            SetTextFont(4)
            SetTextProportional(1)
            SetTextScale(0.7, 0.7)
            SetTextColour(0, 255, 0, 255)
            SetTextOutline()
            SetTextEntry("STRING")
            AddTextComponentString("PIT is clear!")
            DrawText(Config.TextPosition.x, Config.TextPosition.y)
        end
    end
end)
